# Changelog

## 2.0.0

- **Major**: TailwindCSS 4
- **Major**: daisyUI 5 beta
- **Major**: React 19
- **Change**: Pricing section design
- **Change**: Footer design
- **Change**: Overall minor design
- **Replace**: TailwindCSS based icons (iconify)

## 1.1.0

- **Add**: Login & Register modal
- **Update**: All dependencies to latest
- **Fix**: Scroll bug 

## 1.0.0

- Initial Release
